# Import Required Libraries

# Data processing, CSV file reading
import pandas as pd

# Linear Algebra
import numpy as np

import os

from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.model_selection import cross_val_score

from xgboost import XGBRegressor


for dirname, _, filenames in os.walk("data"):
    for filename in filenames:
        print(os.path.join(dirname, filename))
        
        
# split data into train test dataset for predictions

from sklearn.model_selection import train_test_split

# Loading Training data and Test Data
train_data_file = "data/train.csv"
test_data_file = "data/test.csv"

X = pd.read_csv(train_data_file, index_col = "Id")
X_test = pd.read_csv(test_data_file, index_col = "Id")

X.dropna(axis = 0, subset=["SalePrice"], inplace=True)
y = X.SalePrice
X.drop(["SalePrice"], axis=1, inplace=True)

X.head()


low_cardinality_columns = [col for col in X.columns if X[col].nunique() < 10 and X[col].dtype == "object"]
num_columns = [col for col in X.columns if X[col].dtype in ["int64", "float64"]]

required_columns = low_cardinality_columns + num_columns
high_cardinality_columns = [col for col in X.columns if col not in required_columns]

print(required_columns)
print("Dropped_columns: ",high_cardinality_columns)



import pickle

xgb_regressor_model = XGBRegressor(n_estimators=res[0],
                                  learning_rate=res[1],
                                  random_state=0,
                                  n_jobs=4)

model_pipeline = Pipeline(steps=[
    ("preprocessor", preprocessor),
    ("model_run", xgb_regressor_model)
])

# Fitting the input and predicting the results
model_pipeline.fit(X, y)

# Saving the model to load it quickly in case we want to reuse it.
pickle.dump(model_pipeline, open("housing_price_model.pkl", "wb"))

# In case you want to predict without training the model again
# model_pipeline - pickle.load(open("housing_price_model.pkl", "rb"))

# Model Prediction
preds = model_pipeline.predict(X_test)


output = pd.DataFrame({"Id": X_test.index, "SalePrice":preds})
output.to_csv("submission.csv",index=True)

output.head()